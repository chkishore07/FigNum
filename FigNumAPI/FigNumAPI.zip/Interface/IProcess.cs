﻿using System.Collections.Generic;

namespace FigNumAPI.Interface
{

    //Interface fot method declaration
    public interface IProcess
    {
        public List<string> NonPrimeNumbers(string strList);
    }
}
